return {
	{
		"bjarneo/ash.nvim",
		name = "ash",
	},
	{
		"LazyVim/LazyVim",
		opts = {
			colorscheme = "ash",
		},
	},
}
